plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.local.assistente"
    compileSdk = 34

    defaultConfig {
        // Id exclusivo da versão de teste: instala ao lado da v0.7 (br.local.assistente).
        // O namespace acima continua igual, então o código não muda.
        applicationId = "br.local.assistente.v08"
        minSdk = 26
        targetSdk = 34
        versionCode = 8
        versionName = "0.8-teste"
    }

    // Chave fixa de teste: assim cada compilação nova instala por cima da anterior.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Armazenamento criptografado da memória do assistente
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
}
