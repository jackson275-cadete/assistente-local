package br.local.assistente

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.Properties
import java.util.concurrent.CountDownLatch
import kotlin.concurrent.thread

/*
 * Testes das regras da memória (NucleoMemoria), sem Android.
 *
 * Observação: estes testes ainda NÃO estão ligados ao Gradle (o build.gradle.kts não declara
 * JUnit) e, por isso, não rodam na compilação do GitHub. Foram executados à parte, com o
 * compilador Kotlin e o JUnit 4 disponíveis no ambiente de desenvolvimento.
 * Eles não substituem o teste no aparelho, onde entra a criptografia real.
 */

/** Armazém em memória simples, com contadores para provar que nada foi gravado ou removido. */
class ArmazemEmMemoria : ArmazemChaveValor {
    val mapa = linkedMapOf<String, String>()
    var gravacoes = 0
    var remocoes = 0

    override fun ler(chave: String): String? = mapa[chave]
    override fun gravar(chave: String, valor: String): Boolean {
        gravacoes++
        mapa[chave] = valor
        return true
    }
    override fun remover(chave: String): Boolean {
        remocoes++
        mapa.remove(chave)
        return true
    }
    override fun limpar(): Boolean {
        mapa.clear()
        return true
    }
    override fun todos(): Map<String, String> = LinkedHashMap(mapa)
}

/**
 * Imita o comportamento do SharedPreferences do Android: a gravação muda a memória primeiro e
 * só depois tenta o disco; se o disco falha, commit() devolve false mas a memória já mudou.
 * Também permite injetar falhas de criptografia.
 */
class ArmazemSimulaPrefs(val disco: MutableMap<String, String> = mutableMapOf()) : ArmazemChaveValor {
    val memoria = disco.toMutableMap()
    var discoFalha = false
    var criptoFalhaAoLer = false
    var criptoFalhaAoGravar = false
    var criptoFalhaAoLimpar = false
    var criptoFalhaAoListar = false
    var gravaMasNaoPersiste = false
    var remocoes = 0

    override fun ler(chave: String): String? {
        if (criptoFalhaAoLer) throw FalhaArmazem(true, "Falha ao decifrar um valor (simulada)")
        return memoria[chave]
    }

    override fun gravar(chave: String, valor: String): Boolean {
        if (criptoFalhaAoGravar) throw FalhaArmazem(true, "Falha ao cifrar um valor (simulada)")
        if (gravaMasNaoPersiste) return true
        memoria[chave] = valor
        if (discoFalha) return false
        disco[chave] = valor
        return true
    }

    override fun remover(chave: String): Boolean {
        remocoes++
        memoria.remove(chave)
        if (discoFalha) return false
        disco.remove(chave)
        return true
    }

    override fun limpar(): Boolean {
        if (criptoFalhaAoLimpar) throw FalhaArmazem(true, "Falha de criptografia ao apagar (simulada)")
        memoria.clear()
        if (discoFalha) return false
        disco.clear()
        return true
    }

    override fun todos(): Map<String, String> {
        if (criptoFalhaAoListar) throw FalhaArmazem(true, "Falha ao decifrar a memória (simulada)")
        return HashMap(memoria)
    }

    /** Novo "processo": começa só com o que está no disco. */
    fun reiniciar(): ArmazemSimulaPrefs = ArmazemSimulaPrefs(disco)
}

/** Armazém que guarda num arquivo de verdade, para provar persistência entre instâncias e processos. */
class ArmazemEmArquivo(private val arquivo: File) : ArmazemChaveValor {
    private fun carregar(): Properties {
        val p = Properties()
        if (arquivo.exists()) arquivo.inputStream().use { p.load(it) }
        return p
    }

    private fun salvarArquivo(p: Properties): Boolean {
        val tmp = File(arquivo.path + ".tmp")
        tmp.outputStream().use { p.store(it, null) }
        return tmp.renameTo(arquivo)
    }

    override fun ler(chave: String): String? = carregar().getProperty(chave)
    override fun gravar(chave: String, valor: String): Boolean {
        val p = carregar()
        p.setProperty(chave, valor)
        return salvarArquivo(p)
    }
    override fun remover(chave: String): Boolean {
        val p = carregar()
        p.remove(chave)
        return salvarArquivo(p)
    }
    override fun limpar(): Boolean = salvarArquivo(Properties())
    override fun todos(): Map<String, String> {
        val p = carregar()
        val mapa = mutableMapOf<String, String>()
        for (k in p.stringPropertyNames()) mapa[k] = p.getProperty(k)
        return mapa
    }
}

/** Programa de apoio: roda em outra JVM para provar persistência entre processos. */
object ProcessoAuxiliar {
    @JvmStatic
    fun main(args: Array<String>) {
        val nucleo = NucleoMemoria(ArmazemEmArquivo(File(args[1])))
        // Saída em UTF-8 de propósito: o terminal do ambiente pode ser só ASCII e trocaria o "í" por "?".
        val saida = java.io.PrintStream(System.out, true, "UTF-8")
        when (args[0]) {
            "escrever" -> {
                val r1 = nucleo.salvar("nome", "Ana María")
                val r2 = nucleo.salvar("vip_nomes", "x".repeat(600))
                saida.println("${r1.name},${r2.name}")
            }
            "ler" -> {
                saida.println(nucleo.texto("nome"))
                saida.println(nucleo.texto("vip_nomes").length)
            }
        }
    }
}

class NucleoMemoriaTest {

    @get:Rule
    val pasta = TemporaryFolder()

    // ---------- 1. Gravação e leitura de valores válidos ----------

    @Test
    fun gravaELeValorValido() {
        val a = ArmazemEmMemoria()
        val n = NucleoMemoria(a)
        assertEquals(ResultadoGravacao.GRAVADO, n.salvar("nome", "Maria"))
        assertEquals("Maria", n.texto("nome"))
        assertTrue(n.salvar("nome", "João").ok)
        assertEquals("João", n.texto("nome"))
    }

    @Test
    fun todasAsChavesFixasEOsPrefixosSaoAceitos() {
        val n = NucleoMemoria(ArmazemEmMemoria())
        val chaves = listOf(
            "nome", "silencio_ini", "silencio_fim", "voz_ativa", "voz_vel", "voz_tom",
            "voz_nome", "auto_inicio", "ativo", "vip_nomes", "vip_ativo", "vip_fura_silencio",
            "n_bat_baixa", "ult_resumo"
        )
        for (c in chaves) assertEquals("chave $c", ResultadoGravacao.GRAVADO, n.salvar(c, "1"))
    }

    @Test
    fun inteiroELongoLemValoresGravadosEUsamPadraoQuandoAusentes() {
        val n = NucleoMemoria(ArmazemEmMemoria())
        assertEquals(22, n.inteiro("silencio_ini", 22))
        assertEquals(0L, n.longo("n_x"))
        n.salvar("silencio_ini", "21")
        n.salvar("n_x", "1234567")
        assertEquals(21, n.inteiro("silencio_ini", 22))
        assertEquals(1234567L, n.longo("n_x"))
    }

    // ---------- 2. Rejeição de valores inválidos ----------

    @Test
    fun chaveForaDaListaERecusadaSemTocarNoArmazenamento() {
        val a = ArmazemEmMemoria()
        val n = NucleoMemoria(a)
        assertEquals(ResultadoGravacao.CHAVE_NAO_PERMITIDA, n.salvar("senha", "abc"))
        assertFalse(n.salvar("qualquer", "x").ok)
        assertEquals(0, a.gravacoes)
        assertTrue(a.mapa.isEmpty())
    }

    @Test
    fun numerosLongosSaoRecusadosComoNaV07() {
        val a = ArmazemEmMemoria()
        val n = NucleoMemoria(a)
        for (v in listOf("12345678", "1234 5678", "meu cpf 123 456 789 01 ok", "Maria 11 99999 9999")) {
            assertEquals("valor [$v]", ResultadoGravacao.VALOR_RECUSADO, n.salvar("nome", v))
        }
        assertEquals(0, a.gravacoes)
        // Sete dígitos seguidos e números separados por hífen continuam aceitos, como na v0.7.
        assertTrue(n.salvar("nome", "1234567").ok)
        assertTrue(n.salvar("nome", "12-345-678").ok)
    }

    @Test
    fun valorRecusadoNaoSubstituiValorValidoAnterior() {
        val a = ArmazemEmMemoria()
        val n = NucleoMemoria(a)
        n.salvar("vip_nomes", "Maria, João")
        val antes = a.gravacoes

        assertEquals(ResultadoGravacao.VALOR_RECUSADO, n.salvar("vip_nomes", "Maria 11999999999"))
        assertEquals(ResultadoGravacao.VALOR_MUITO_LONGO, n.salvar("vip_nomes", "a".repeat(601)))
        assertEquals(ResultadoGravacao.CHAVE_NAO_PERMITIDA, n.salvar("vip_nomes_x", "ok"))

        assertEquals("Maria, João", n.texto("vip_nomes"))
        assertEquals(antes, a.gravacoes)
        assertEquals(0, a.remocoes)
    }

    // ---------- 3. Tamanho: sem truncamento ----------

    @Test
    fun valorDeExatamente600CaracteresEGuardadoIntegro() {
        val n = NucleoMemoria(ArmazemEmMemoria())
        val valor = ("Maria José, Ação; Inês ão. ").repeat(30).take(600)
        assertEquals(600, valor.length)
        assertEquals(ResultadoGravacao.GRAVADO, n.salvar("vip_nomes", valor))
        assertEquals(valor, n.texto("vip_nomes"))
    }

    @Test
    fun valorDe601OuMaisCaracteresERecusadoSemCortar() {
        val a = ArmazemEmMemoria()
        val n = NucleoMemoria(a)
        for (tam in listOf(601, 602, 1000, 5000)) {
            assertEquals("tamanho $tam", ResultadoGravacao.VALOR_MUITO_LONGO, n.salvar("vip_nomes", "a".repeat(tam)))
        }
        assertEquals(0, a.gravacoes)
        assertEquals("", n.texto("vip_nomes"))
    }

    @Test
    fun limiteContaUnidadesUtf16ComoAV07() {
        val n = NucleoMemoria(ArmazemEmMemoria())
        assertEquals(600, "😀".repeat(300).length)
        assertTrue(n.salvar("nome", "😀".repeat(300)).ok)
        assertEquals(ResultadoGravacao.VALOR_MUITO_LONGO, n.salvar("nome", "😀".repeat(301)))
    }

    // ---------- 4. Timestamps internos (ult_hist, ult_<regra>) ----------

    private val idsDasRegras = listOf(
        "bat_critica", "bat_baixa", "bat_80", "quente", "armazenamento", "ram", "bat_queda"
    )

    @Test
    fun timestampsLegitimosSaoGravadosNasChavesInternas() {
        val n = NucleoMemoria(ArmazemEmMemoria())
        val agora = "1795006315000"
        assertTrue(n.salvar("ult_hist", agora).ok)
        for (id in idsDasRegras) assertTrue("ult_$id", n.salvar("ult_$id", agora).ok)
        assertEquals(1795006315000L, n.longo("ult_hist"))
        assertEquals(1795006315000L, n.longo("ult_ram"))
        // 12 dígitos (a partir de 2000) também são timestamps válidos.
        assertTrue(n.salvar("ult_hist", "999999999999").ok)
        // Contadores e data do resumo continuam passando.
        assertTrue(n.salvar("n_bat_baixa", "3").ok)
        assertTrue(n.salvar("ult_resumo", "2026-11-21").ok)
    }

    @Test
    fun timestampInvalidoNaChaveInternaEhRecusadoEPreservaOAnterior() {
        val n = NucleoMemoria(ArmazemEmMemoria())
        assertTrue(n.salvar("ult_hist", "1795006315000").ok)
        val invalidos = listOf(
            "17950063150000",        // 14 dígitos
            "179500631500",          // 12 dígitos, mas é 1975: fora de 2000–2100
            "0001795006315",         // zeros à esquerda
            "0946684800000",         // zero à esquerda, valor dentro da faixa
            "+1795006315000",        // sinal que toLong() aceitaria
            "1795006315000 ",        // espaço no fim
            " 1795006315000",
            "1795 0063 15000",       // dígitos separados por espaço
            "1795006315000\n1",
            "-1795006315000",
            "1795006315000.5",
            "4111111111111111",      // 16 dígitos (cartão)
            "4111 1111 1111 1111",
            "5000000000000",         // 13 dígitos depois de 2100
            "946684799999",          // 1 ms antes de 2000
            "12345678",              // 8 dígitos
            "abc1795006315000"
        )
        for (v in invalidos) {
            assertFalse("deveria recusar [$v]", n.salvar("ult_hist", v).ok)
            assertEquals("anterior mudou após [$v]", 1795006315000L, n.longo("ult_hist"))
        }
    }

    @Test
    fun excecaoNaoSeEstendeAOutrasChaves() {
        val n = NucleoMemoria(ArmazemEmMemoria())
        val ts = "1795006315000"
        // Chaves fixas, contadores, data do resumo e ids de timestamp desconhecidos continuam com a regra geral.
        for (k in listOf("nome", "vip_nomes", "voz_nome", "n_bat_baixa", "ult_resumo", "ult_qualquer", "ult_hist2", "ult_", "ult_hist ")) {
            assertEquals("chave $k", ResultadoGravacao.VALOR_RECUSADO, n.salvar(k, ts))
        }
        // Chave fora da lista continua recusada por chave, não por valor.
        assertEquals(ResultadoGravacao.CHAVE_NAO_PERMITIDA, n.salvar("senha", ts))
        assertEquals(ResultadoGravacao.CHAVE_NAO_PERMITIDA, n.salvar("hist", ts))
        // Número longo em texto continua recusado nas chaves comuns, mesmo com espaços.
        assertEquals(ResultadoGravacao.VALOR_RECUSADO, n.salvar("nome", "4111 1111 1111 1111"))
        assertEquals(ResultadoGravacao.VALOR_RECUSADO, n.salvar("vip_nomes", "Ana, 11999998888"))
    }

    @Test
    fun timestampNaoContornaOLimiteDeTamanhoNemEmbuteNumeroLongo() {
        val n = NucleoMemoria(ArmazemEmMemoria())
        assertEquals(ResultadoGravacao.VALOR_MUITO_LONGO, n.salvar("ult_hist", "1".repeat(601)))
        assertEquals(ResultadoGravacao.VALOR_RECUSADO, n.salvar("ult_hist", "1795006315000" + "1795006315000"))
        assertEquals(ResultadoGravacao.VALOR_RECUSADO, n.salvar("ult_hist", "1795006315000,4111111111111111"))
        assertEquals(ResultadoGravacao.VALOR_RECUSADO, n.salvar("ult_bat_ram", "1795006315000"))
    }

    @Test
    fun validarEhPuroETimestampValidoConfereChaveEFormato() {
        assertTrue(NucleoMemoria.timestampValido("ult_hist", "1795006315000"))
        assertFalse(NucleoMemoria.timestampValido("nome", "1795006315000"))
        assertFalse(NucleoMemoria.timestampValido("ult_hist", "17950063150"))
        assertNull(NucleoMemoria.validar("ult_ram", "1795006315000"))
        assertEquals(ResultadoGravacao.VALOR_RECUSADO, NucleoMemoria.validar("n_ram", "1795006315000"))
    }

    // Reproduz a mesma lógica do MonitorService.verificar() (mesma expressão de espera e mesma ordem de
    // leitura/gravação) sobre o núcleo, sem o Android. Não roda o MonitorService de verdade.
    private fun avisaAgora(n: NucleoMemoria, id: String, agora: Long, intervaloMs: Long): Boolean {
        val vezes = n.inteiro("n_$id", 0)
        val espera = (intervaloMs * (1f + minOf(vezes, 20) / 10f)).toLong()
        val ultimo = n.longo("ult_$id")
        if (agora - ultimo < espera) return false
        n.salvar("ult_$id", agora.toString())
        n.salvar("n_$id", (vezes + 1).toString())
        return true
    }

    private fun gravaHistoricoAgora(n: NucleoMemoria, agora: Long): Boolean {
        if (agora - n.longo("ult_hist") >= 15 * 60_000L) {
            n.salvar("ult_hist", agora.toString())
            return true
        }
        return false
    }

    @Test
    fun intervaloDeAlertaPassaAFuncionarComTimestampReal() {
        val n = NucleoMemoria(ArmazemEmMemoria())
        val min = 60_000L
        val t0 = 1795006315000L
        assertTrue(avisaAgora(n, "bat_baixa", t0, 60 * min))
        // A cada ciclo de 5 minutos, sem repetir antes do intervalo (60 min x 1,1 na 2ª vez).
        for (k in 1..11) assertFalse("ciclo $k", avisaAgora(n, "bat_baixa", t0 + k * 5 * min, 60 * min))
        assertTrue(avisaAgora(n, "bat_baixa", t0 + 66 * min, 60 * min))
        assertEquals(2, n.inteiro("n_bat_baixa", 0))
        assertEquals(t0 + 66 * min, n.longo("ult_bat_baixa"))
    }

    @Test
    fun intervaloDoHistoricoFuncionaESobreviveANovaInstancia() {
        val min = 60_000L
        val t0 = 1795006315000L
        val arq = File.createTempFile("mem", ".txt").also { it.deleteOnExit() }
        val a = NucleoMemoria(ArmazemEmArquivo(arq))
        assertTrue(gravaHistoricoAgora(a, t0))
        assertFalse(gravaHistoricoAgora(a, t0 + 5 * min))
        // "Reinício do serviço": nova instância sobre o mesmo arquivo continua respeitando o intervalo.
        val b = NucleoMemoria(ArmazemEmArquivo(arq))
        assertEquals(t0, b.longo("ult_hist"))
        assertFalse(gravaHistoricoAgora(b, t0 + 10 * min))
        assertTrue(gravaHistoricoAgora(b, t0 + 15 * min))
        assertEquals(t0 + 15 * min, NucleoMemoria(ArmazemEmArquivo(arq)).longo("ult_hist"))
    }

    // ---------- 5. Falhas de gravação ----------

    @Test
    fun falhaDeDiscoMantemOValorAnteriorNaMemoriaENoDisco() {
        val s = ArmazemSimulaPrefs()
        val n = NucleoMemoria(s)
        assertTrue(n.salvar("nome", "Maria").ok)

        s.discoFalha = true
        val r = n.salvar("nome", "João")

        assertEquals(ResultadoGravacao.FALHA_GRAVACAO, r)
        assertFalse(n.salvar("nome", "Pedro").ok)
        assertEquals("Maria", s.memoria["nome"])
        assertEquals("Maria", s.disco["nome"])
        assertEquals("Maria", n.texto("nome"))
        assertEquals("Maria", s.reiniciar().ler("nome"))
        assertNotNull(n.ultimoErro)
    }

    @Test
    fun falhaDeDiscoEmChaveNovaNaoDeixaRastro() {
        val s = ArmazemSimulaPrefs()
        val n = NucleoMemoria(s)
        s.discoFalha = true
        assertEquals(ResultadoGravacao.FALHA_GRAVACAO, n.salvar("nome", "Maria"))
        assertFalse(s.memoria.containsKey("nome"))
        assertFalse(s.disco.containsKey("nome"))
        assertEquals("", n.texto("nome"))
    }

    @Test
    fun gravacaoNaoConfirmadaNaReleituraEFalha() {
        val s = ArmazemSimulaPrefs()
        val n = NucleoMemoria(s)
        n.salvar("nome", "Maria")
        s.gravaMasNaoPersiste = true
        assertEquals(ResultadoGravacao.FALHA_GRAVACAO, n.salvar("nome", "João"))
        assertEquals("Maria", n.texto("nome"))
    }

    // ---------- 6. Falhas de criptografia ----------

    @Test
    fun falhaDeCriptografiaAoGravarMantemOAnteriorEDizOMotivo() {
        val s = ArmazemSimulaPrefs()
        val n = NucleoMemoria(s)
        n.salvar("nome", "Maria")
        s.criptoFalhaAoGravar = true
        assertEquals(ResultadoGravacao.FALHA_CRIPTOGRAFIA, n.salvar("nome", "João"))
        s.criptoFalhaAoGravar = false
        assertEquals("Maria", n.texto("nome"))
        assertEquals("Maria", s.reiniciar().ler("nome"))
    }

    @Test
    fun falhaDeCriptografiaAoLerDevolvePadraoSemLancarErro() {
        val s = ArmazemSimulaPrefs()
        val n = NucleoMemoria(s)
        n.salvar("nome", "Maria")
        s.criptoFalhaAoLer = true
        s.criptoFalhaAoListar = true
        assertEquals("padrão", n.texto("nome", "padrão"))
        assertEquals(7, n.inteiro("silencio_ini", 7))
        val leitura = n.lerTudo()
        assertTrue(leitura.dados.isEmpty())
        assertNotNull(leitura.erro)
        assertNotNull(n.ultimoErro)
    }

    @Test
    fun valorAnteriorIlegivelNaoEApagadoNemSubstituidoNoDesfazer() {
        val s = ArmazemSimulaPrefs()
        val n = NucleoMemoria(s)
        n.salvar("nome", "Maria")
        s.criptoFalhaAoLer = true // não dá para ler o anterior nem reler depois de gravar
        val r = n.salvar("nome", "João")
        assertEquals(ResultadoGravacao.FALHA_CRIPTOGRAFIA, r)
        assertEquals(0, s.remocoes) // nada foi removido às cegas
    }

    @Test
    fun memoriaIndisponivelNaoGravaENaoLanca() {
        val n = NucleoMemoria(null, "Falha de criptografia ao abrir a memória (teste)")
        assertFalse(n.disponivel)
        assertEquals(ResultadoGravacao.MEMORIA_INDISPONIVEL, n.salvar("nome", "Maria"))
        assertEquals(ResultadoGravacao.MEMORIA_INDISPONIVEL, n.esquecerTudo())
        assertEquals("padrão", n.texto("nome", "padrão"))
        assertTrue(n.tudo().isEmpty())
        assertEquals("Falha de criptografia ao abrir a memória (teste)", n.lerTudo().erro)
        // A validação continua valendo mesmo sem armazenamento.
        assertEquals(ResultadoGravacao.VALOR_MUITO_LONGO, n.salvar("nome", "a".repeat(601)))
    }

    @Test
    fun mensagensEErrosNuncaTrazemOConteudoGuardado() {
        val segredo = "SEGREDO-ABC"
        val s = ArmazemSimulaPrefs()
        val n = NucleoMemoria(s)
        s.criptoFalhaAoGravar = true
        val r1 = n.salvar("nome", segredo)
        s.criptoFalhaAoGravar = false
        s.discoFalha = true
        val r2 = n.salvar("nome", segredo)
        for (r in ResultadoGravacao.values()) assertFalse(r.mensagem.contains(segredo))
        assertFalse(r1.mensagem.contains(segredo))
        assertFalse(r2.mensagem.contains(segredo))
        assertFalse((n.ultimoErro ?: "").contains(segredo))
    }

    // ---------- 7. Exclusão ----------

    @Test
    fun esquecerTudoApagaEConfereQueFicouVazio() {
        val a = ArmazemEmMemoria()
        val n = NucleoMemoria(a)
        n.salvar("nome", "Maria")
        n.salvar("vip_nomes", "João")
        assertEquals(ResultadoGravacao.GRAVADO, n.esquecerTudo())
        assertTrue(n.tudo().isEmpty())
    }

    @Test
    fun esquecerTudoComFalhaDeDiscoRestauraOConteudo() {
        val s = ArmazemSimulaPrefs()
        val n = NucleoMemoria(s)
        n.salvar("nome", "Maria")
        n.salvar("vip_nomes", "João, Ana")
        val antes = HashMap(s.disco)

        s.discoFalha = true
        assertEquals(ResultadoGravacao.FALHA_GRAVACAO, n.esquecerTudo())

        assertEquals(antes, HashMap(s.memoria))
        assertEquals(antes, HashMap(s.disco))
        assertEquals("João, Ana", n.texto("vip_nomes"))
    }

    @Test
    fun esquecerTudoComFalhaDeCriptografiaNaoApagaNada() {
        val s = ArmazemSimulaPrefs()
        val n = NucleoMemoria(s)
        n.salvar("nome", "Maria")
        s.criptoFalhaAoLimpar = true
        assertEquals(ResultadoGravacao.FALHA_CRIPTOGRAFIA, n.esquecerTudo())
        assertEquals("Maria", n.texto("nome"))
        assertEquals("Maria", s.disco["nome"])
    }

    // ---------- 8. Persistência: nova instância e outro processo ----------

    @Test
    fun valoresSobrevivemANovaInstanciaComArmazenamentoEmArquivo() {
        val arquivo = File(pasta.root, "memoria.properties")
        val n1 = NucleoMemoria(ArmazemEmArquivo(arquivo))
        assertTrue(n1.salvar("nome", "Ana María").ok)
        assertTrue(n1.salvar("vip_nomes", "Maria, João\nPedro").ok)

        val n2 = NucleoMemoria(ArmazemEmArquivo(arquivo)) // instância nova, sem estado em RAM
        assertEquals("Ana María", n2.texto("nome"))
        assertEquals("Maria, João\nPedro", n2.texto("vip_nomes"))
    }

    @Test
    fun valoresSobrevivemARecriacaoDoProcesso() {
        val arquivo = File(pasta.root, "memoria_processos.properties")
        val r1 = executarProcesso("escrever", arquivo)
        assertEquals("GRAVADO,GRAVADO", r1.lines().first())
        val r2 = executarProcesso("ler", arquivo).lines()
        assertEquals("Ana María", r2[0])
        assertEquals("600", r2[1]) // o valor lido por outro processo tem 600 caracteres, sem corte
    }

    private fun executarProcesso(modo: String, arquivo: File): String {
        val java = File(System.getProperty("java.home"), "bin/java").path
        val cp = System.getProperty("java.class.path")
        val p = ProcessBuilder(java, "-cp", cp, "br.local.assistente.ProcessoAuxiliar", modo, arquivo.path)
            .redirectErrorStream(false)
            .start()
        val saida = p.inputStream.bufferedReader().readText()
        val codigo = p.waitFor()
        assertEquals("o processo auxiliar terminou com erro", 0, codigo)
        return saida.trim()
    }

    // ---------- 9. Concorrência ----------

    @Test
    fun gravacoesSimultaneasNaoSePerdem() {
        val a = ArmazemEmMemoria()
        val n = NucleoMemoria(a)
        val largada = CountDownLatch(1)
        val threads = (0 until 8).map { t ->
            thread {
                largada.await()
                for (j in 0 until 100) n.salvar("n_t${t}_$j", "$j")
            }
        }
        largada.countDown()
        threads.forEach { it.join() }
        assertEquals(800, a.mapa.size)
    }
}
