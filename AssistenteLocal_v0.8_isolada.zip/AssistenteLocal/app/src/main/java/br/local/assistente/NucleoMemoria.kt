package br.local.assistente

/**
 * Regras da memória do assistente, sem nenhuma dependência do Android.
 *
 * Fica separado de [Memoria] para que as regras possam ser testadas fora do aparelho.
 * Nada aqui apaga, corta ou troca um dado válido sem que a gravação nova seja
 * confirmada. Nenhuma mensagem de erro inclui o conteúdo guardado.
 */

/**
 * Resultado de uma tentativa de gravar ou apagar.
 * Só [GRAVADO] significa que a operação chegou ao armazenamento e foi confirmada.
 */
enum class ResultadoGravacao(val mensagem: String) {
    GRAVADO("Salvo."),
    CHAVE_NAO_PERMITIDA("Esse dado não pode ser guardado pela memória."),
    VALOR_MUITO_LONGO("O texto passa de ${NucleoMemoria.MAX_VALOR} caracteres. Nada foi salvo, cortado ou alterado."),
    VALOR_RECUSADO("O valor parece um número longo (cartão, documento ou telefone) e não é guardado."),
    FALHA_CRIPTOGRAFIA("Falha de criptografia. Nada foi alterado."),
    FALHA_GRAVACAO("Não consegui concluir a gravação no aparelho. O conteúdo anterior foi mantido."),
    MEMORIA_INDISPONIVEL("A memória criptografada não está disponível. Nada foi salvo.");

    val ok: Boolean get() = this == GRAVADO
}

/** Falha do armazenamento. [criptografia] indica se a causa foi cifrar ou decifrar. */
class FalhaArmazem(
    val criptografia: Boolean,
    mensagem: String,
    causa: Throwable? = null
) : Exception(mensagem, causa)

/** Armazenamento de pares texto/texto. Gravar só devolve true se a escrita foi confirmada. */
interface ArmazemChaveValor {
    /** Valor guardado, ou null se não existe. Lança [FalhaArmazem] se não conseguir ler ou decifrar. */
    @Throws(FalhaArmazem::class)
    fun ler(chave: String): String?

    /** true só se a escrita foi confirmada pelo armazenamento. */
    @Throws(FalhaArmazem::class)
    fun gravar(chave: String, valor: String): Boolean

    /** true só se a remoção foi confirmada pelo armazenamento. */
    @Throws(FalhaArmazem::class)
    fun remover(chave: String): Boolean

    /** true só se o apagamento total foi confirmado pelo armazenamento. */
    @Throws(FalhaArmazem::class)
    fun limpar(): Boolean

    @Throws(FalhaArmazem::class)
    fun todos(): Map<String, String>
}

/** Leitura completa: [erro] é null quando tudo foi lido sem problema. */
class LeituraMemoria(val dados: Map<String, String>, val erro: String?)

class NucleoMemoria(
    private val armazem: ArmazemChaveValor?,
    /** Explica por que não há armazenamento (só preenchido quando [armazem] é null). */
    val motivoIndisponivel: String? = null,
    /** Trava compartilhada entre instâncias do mesmo processo. */
    private val trava: Any = Any()
) {

    companion object {
        /** Tamanho máximo de um valor, em caracteres. Acima disso o valor é recusado, nunca cortado. */
        const val MAX_VALOR = 600

        private val CHAVES_FIXAS = setOf(
            "nome", "silencio_ini", "silencio_fim", "voz_ativa",
            "voz_vel", "voz_tom", "voz_nome", "auto_inicio", "ativo",
            "vip_nomes", "vip_ativo", "vip_fura_silencio"
        )
        private val NUMERO_LONGO = Regex("\\d{8,}")

        /**
         * Chaves internas que guardam o instante da última execução, em milissegundos desde 1970
         * (System.currentTimeMillis(), 12 ou 13 dígitos). Os ids vêm das regras do MonitorService.
         * É lista fechada: um novo id de regra precisa ser acrescentado aqui de propósito.
         * "ult_resumo" não entra: guarda uma data (AAAA-MM-DD), que já passa pela regra geral.
         */
        private val CHAVES_TIMESTAMP = setOf(
            "ult_hist",
            "ult_bat_critica", "ult_bat_baixa", "ult_bat_80", "ult_quente",
            "ult_armazenamento", "ult_ram", "ult_bat_queda"
        )
        private val FORMATO_TIMESTAMP = Regex("[1-9]\\d{11,12}")
        /** 01/01/2000 e 01/01/2100 em milissegundos. */
        private const val TIMESTAMP_MIN = 946_684_800_000L
        private const val TIMESTAMP_MAX = 4_102_444_800_000L

        fun permitido(chave: String): Boolean =
            chave in CHAVES_FIXAS || chave.startsWith("n_") || chave.startsWith("ult_")

        /** true só para chave de timestamp e valor só de dígitos (sem espaços), entre 2000 e 2100. */
        fun timestampValido(chave: String, valor: String): Boolean {
            if (chave !in CHAVES_TIMESTAMP) return false
            if (!FORMATO_TIMESTAMP.matches(valor)) return false
            val n = valor.toLongOrNull() ?: return false
            return n in TIMESTAMP_MIN..TIMESTAMP_MAX
        }

        /**
         * Confere chave e valor sem gravar nada.
         * Devolve null se forem válidos, ou o motivo da recusa.
         * Mesmas regras da v0.7 (chave permitida, números longos recusados),
         * mais o limite de tamanho, que antes cortava o texto em silêncio.
         */
        fun validar(chave: String, valor: String): ResultadoGravacao? {
            if (!permitido(chave)) return ResultadoGravacao.CHAVE_NAO_PERMITIDA
            if (valor.length > MAX_VALOR) return ResultadoGravacao.VALOR_MUITO_LONGO
            // Única exceção à regra de número longo: timestamp legítimo em chave de timestamp.
            if (timestampValido(chave, valor)) return null
            if (NUMERO_LONGO.containsMatchIn(valor.replace(" ", ""))) return ResultadoGravacao.VALOR_RECUSADO
            return null
        }
    }

    /** Descrição do erro mais recente (sem conteúdo guardado). Não é apagada por operações seguintes. */
    @Volatile
    var ultimoErro: String? = null
        private set

    val disponivel: Boolean get() = armazem != null

    /**
     * Grava um valor e confere o resultado real.
     * - Valor inválido: nada é gravado e o valor anterior fica como estava.
     * - Falha ao gravar: o valor anterior é restaurado e a falha é devolvida.
     * - Só devolve [ResultadoGravacao.GRAVADO] depois de reler o valor e achá-lo igual ao enviado.
     */
    fun salvar(chave: String, valor: String): ResultadoGravacao {
        val recusa = validar(chave, valor)
        if (recusa != null) return recusa
        val a = armazem ?: return ResultadoGravacao.MEMORIA_INDISPONIVEL
        return synchronized(trava) { salvarTravado(a, chave, valor) }
    }

    private fun salvarTravado(a: ArmazemChaveValor, chave: String, valor: String): ResultadoGravacao {
        var anteriorConhecido = true
        var anterior: String? = null
        try {
            anterior = a.ler(chave)
        } catch (e: FalhaArmazem) {
            registrar(e)
            anteriorConhecido = false
        }

        var falha: FalhaArmazem? = null
        var gravou = false
        try {
            gravou = a.gravar(chave, valor)
        } catch (e: FalhaArmazem) {
            falha = e
        }

        if (falha == null && gravou) {
            try {
                if (a.ler(chave) == valor) return ResultadoGravacao.GRAVADO
            } catch (e: FalhaArmazem) {
                falha = e
            }
        }

        val f = falha
        if (f != null) registrar(f) else ultimoErro = "A gravação não foi confirmada pelo armazenamento."
        if (anteriorConhecido) desfazer(a, chave, anterior)
        return if (f != null && f.criptografia) ResultadoGravacao.FALHA_CRIPTOGRAFIA else ResultadoGravacao.FALHA_GRAVACAO
    }

    /** Devolve a chave ao estado anterior. Não toca em nada se o valor anterior não pôde ser lido. */
    private fun desfazer(a: ArmazemChaveValor, chave: String, anterior: String?) {
        try {
            if (anterior != null) a.gravar(chave, anterior) else a.remover(chave)
        } catch (e: FalhaArmazem) {
            registrar(e)
        }
    }

    fun texto(chave: String, padrao: String = ""): String {
        val a = armazem ?: return padrao
        return synchronized(trava) {
            try {
                a.ler(chave) ?: padrao
            } catch (e: FalhaArmazem) {
                registrar(e)
                padrao
            }
        }
    }

    fun inteiro(chave: String, padrao: Int): Int =
        texto(chave).toIntOrNull() ?: padrao

    fun longo(chave: String, padrao: Long = 0L): Long =
        texto(chave).toLongOrNull() ?: padrao

    /** Tudo o que está guardado, com o motivo da falha quando a leitura não foi possível. */
    fun lerTudo(): LeituraMemoria {
        val a = armazem ?: return LeituraMemoria(emptyMap(), motivoIndisponivel ?: "Memória indisponível.")
        return synchronized(trava) {
            try {
                LeituraMemoria(a.todos(), null)
            } catch (e: FalhaArmazem) {
                registrar(e)
                LeituraMemoria(emptyMap(), e.message ?: "Falha ao ler a memória.")
            }
        }
    }

    /** Compatível com a v0.7. Em caso de falha devolve mapa vazio; use [lerTudo] para saber o motivo. */
    fun tudo(): Map<String, String> = lerTudo().dados

    /**
     * Apaga toda a memória e confere o resultado.
     * Se o apagamento falhar, o conteúdo que existia é restaurado.
     */
    fun esquecerTudo(): ResultadoGravacao {
        val a = armazem ?: return ResultadoGravacao.MEMORIA_INDISPONIVEL
        return synchronized(trava) { esquecerTravado(a) }
    }

    private fun esquecerTravado(a: ArmazemChaveValor): ResultadoGravacao {
        var copia: Map<String, String>? = null
        try {
            copia = a.todos()
        } catch (e: FalhaArmazem) {
            registrar(e)
        }

        var falha: FalhaArmazem? = null
        var limpou = false
        try {
            limpou = a.limpar()
        } catch (e: FalhaArmazem) {
            falha = e
        }

        if (falha == null && limpou) {
            return try {
                if (a.todos().isEmpty()) {
                    ResultadoGravacao.GRAVADO
                } else {
                    ultimoErro = "Sobrou conteúdo depois de apagar."
                    ResultadoGravacao.FALHA_GRAVACAO
                }
            } catch (e: FalhaArmazem) {
                registrar(e)
                ResultadoGravacao.FALHA_GRAVACAO
            }
        }

        val f = falha
        if (f != null) registrar(f) else ultimoErro = "O apagamento não foi confirmado pelo armazenamento."
        restaurar(a, copia)
        return if (f != null && f.criptografia) ResultadoGravacao.FALHA_CRIPTOGRAFIA else ResultadoGravacao.FALHA_GRAVACAO
    }

    private fun restaurar(a: ArmazemChaveValor, copia: Map<String, String>?) {
        if (copia == null) return
        for ((k, v) in copia) {
            try {
                a.gravar(k, v)
            } catch (e: FalhaArmazem) {
                registrar(e)
            }
        }
    }

    private fun registrar(e: FalhaArmazem) {
        ultimoErro = e.message
    }
}
