package br.local.assistente

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Process
import android.os.storage.StorageManager
import java.util.Calendar

/** nome do app, um valor (minutos ou MB) e uma observação opcional. */
class AppUso(val nome: String, val valor: Long, val extra: String = "")

/**
 * Descobre quais apps você mais usa e quais ocupam mais espaço.
 * O Android não informa o gasto de bateria de cada app para outros apps, então o tempo
 * de uso na tela é o melhor indicador disponível. Precisa do acesso "uso de apps".
 */
object AppsUso {

    fun temPermissao(ctx: Context): Boolean {
        return try {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val modo = ops.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                ctx.packageName
            )
            modo == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }

    fun inicioDoDia(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun pacoteDaTelaInicial(ctx: Context): String? {
        return try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            ctx.packageManager.resolveActivity(i, 0)?.activityInfo?.packageName
        } catch (_: Exception) {
            null
        }
    }

    /** Nome do app, só para apps que o usuário abre (ignora serviços do sistema). */
    private fun nomeDoApp(ctx: Context, pacote: String): String? {
        val pm = ctx.packageManager
        if (pm.getLaunchIntentForPackage(pacote) == null) return null
        return try {
            pm.getApplicationLabel(pm.getApplicationInfo(pacote, 0)).toString()
        } catch (_: Exception) {
            null
        }
    }

    /** Apps mais usados desde "desde" (milissegundos). O valor é em minutos. */
    fun maisUsados(ctx: Context, desde: Long, quantos: Int): List<AppUso> {
        if (!temPermissao(ctx)) return emptyList()
        return try {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val mapa = usm.queryAndAggregateUsageStats(desde, System.currentTimeMillis())
            val casa = pacoteDaTelaInicial(ctx)
            mapa.values
                .filter {
                    it.totalTimeInForeground >= 60_000L &&
                        it.packageName != ctx.packageName &&
                        it.packageName != casa
                }
                .sortedByDescending { it.totalTimeInForeground }
                .mapNotNull { u ->
                    nomeDoApp(ctx, u.packageName)?.let { AppUso(it, u.totalTimeInForeground / 60_000L) }
                }
                .take(quantos)
        } catch (_: Exception) {
            emptyList()
        }
    }

    /** Ex.: "Instagram, por 35 minutos". Nulo se não houver dado ou permissão. */
    fun maisUsadoUltimaHora(ctx: Context): String? {
        val topo = maisUsados(ctx, System.currentTimeMillis() - 60 * 60_000L, 1).firstOrNull() ?: return null
        return "${topo.nome}, por ${topo.valor} minutos"
    }

    /** Apps que mais ocupam espaço. O valor é em MB e o extra mostra o cache. */
    fun maiores(ctx: Context, quantos: Int): List<AppUso> {
        if (!temPermissao(ctx)) return emptyList()
        return try {
            val ssm = ctx.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
            val casa = pacoteDaTelaInicial(ctx)
            val mb = 1024L * 1024L
            val lista = mutableListOf<AppUso>()
            for (info in ctx.packageManager.getInstalledApplications(0)) {
                val pacote = info.packageName
                if (pacote == casa) continue
                val nome = nomeDoApp(ctx, pacote) ?: continue
                try {
                    val s = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, pacote, Process.myUserHandle())
                    val total = (s.appBytes + s.dataBytes) / mb
                    val cache = s.cacheBytes / mb
                    lista.add(AppUso(nome, total, "cache $cache MB"))
                } catch (_: Exception) {
                    // App sem dados de espaço: ignora.
                }
            }
            lista.sortedByDescending { it.valor }.take(quantos)
        } catch (_: Exception) {
            emptyList()
        }
    }
}
