package br.local.assistente

import android.app.Notification
import android.app.Person
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Avisa quando um contato VIP manda mensagem ou liga.
 * Olha só as notificações dos apps de mensagem da lista abaixo e as de ligação recebida,
 * compara apenas o nome de quem mandou com os nomes VIP e fala só o nome.
 * Não lê, não guarda e não envia o texto das mensagens.
 */
class VipListener : NotificationListenerService() {

    private lateinit var mem: Memoria
    private lateinit var voz: Voz
    private val handler = Handler(Looper.getMainLooper())
    private val ultimoAviso = HashMap<String, Long>()
    private val ligacoes = HashMap<String, Runnable>()

    override fun onCreate() {
        super.onCreate()
        mem = Memoria(this)
        voz = Voz(this, mem)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        ligacoes.clear()
        voz.parar()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            tratar(sbn)
        } catch (_: Exception) {
            // Qualquer falha aqui não pode derrubar o serviço.
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        val chave = sbn?.key ?: return
        encerrarLigacao(chave)
    }

    private fun encerrarLigacao(chave: String) {
        val r = ligacoes.remove(chave) ?: return
        handler.removeCallbacks(r)
    }

    private fun tratar(sbn: StatusBarNotification) {
        if (mem.texto("vip_ativo", "1") != "1") return

        val n = sbn.notification
        val ehLigacao = n.category == Notification.CATEGORY_CALL
        if (!ehLigacao && sbn.packageName !in APPS) return
        if (!ehLigacao && sbn.isOngoing) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        if (ehLigacao && !chamadaRecebida(n)) {
            // Ligação atendida ou em andamento: para de tocar o alerta.
            encerrarLigacao(sbn.key)
            return
        }

        val titulo = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val texto = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (titulo.isBlank() && texto.isBlank()) return

        // Só na memória do aparelho (RAM): ajuda a ver como o nome aparece na notificação.
        registrar(if (ehLigacao) "ligação" else "mensagem", if (ehLigacao) "$titulo | $texto" else titulo)

        val candidatos = mutableListOf<String>()
        if (titulo.isNotBlank()) candidatos.add(titulo)
        if (ehLigacao) {
            if (texto.isNotBlank()) candidatos.add(texto)
            nomeDaLigacao(n)?.let { candidatos.add(it) }
        } else {
            ultimoRemetente(n)?.let { candidatos.add(it) }
        }

        val vips = listaVip(mem.texto("vip_nomes"))
        val achado = candidatos.firstNotNullOfOrNull { acharVip(it, vips) } ?: return

        if (Alerta.emSilencio(mem) && mem.texto("vip_fura_silencio", "0") != "1") return
        val falar = mem.texto("voz_ativa", "1") == "1"

        if (ehLigacao) {
            iniciarAlertaDeLigacao(sbn.key, achado, falar)
            return
        }

        val agora = System.currentTimeMillis()
        val anterior = ultimoAviso[achado] ?: 0L
        if (agora - anterior < 15_000L) return
        ultimoAviso[achado] = agora

        Alerta.chamarAtencao(this, handler)
        if (falar) {
            handler.postDelayed({ voz.falar("Mensagem de $achado.", true) }, 1500)
        }
    }

    /** Toca e fala a cada 7 segundos, até 6 vezes, enquanto a ligação estiver tocando. */
    private fun iniciarAlertaDeLigacao(chave: String, nome: String, falar: Boolean) {
        if (ligacoes.containsKey(chave)) return
        var repeticoes = 0
        val r = object : Runnable {
            override fun run() {
                Alerta.chamarAtencao(this@VipListener, handler)
                if (falar) {
                    handler.postDelayed({ voz.falar("Ligação de $nome.", true) }, 1500)
                }
                repeticoes++
                if (repeticoes < 6) {
                    handler.postDelayed(this, 7000)
                } else {
                    ligacoes.remove(chave)
                }
            }
        }
        ligacoes[chave] = r
        handler.post(r)
    }

    /** Ligação recebida (tocando), e não uma ligação já atendida. */
    private fun chamadaRecebida(n: Notification): Boolean {
        val tipo = n.extras.getInt("android.callType", 0)
        if (tipo == 1) return true
        if (tipo != 0) return false
        if (n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)) return false
        return n.fullScreenIntent != null || (n.actions?.size ?: 0) >= 2
    }

    private fun nomeDaLigacao(n: Notification): String? {
        return try {
            if (Build.VERSION.SDK_INT >= 28) {
                (n.extras.getParcelable<Parcelable>("android.callPerson") as? Person)?.name?.toString()
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Nome de quem mandou a última mensagem da conversa (útil para grupos). */
    private fun ultimoRemetente(n: Notification): String? {
        return try {
            val msgs = n.extras.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return null
            val ultima = msgs.lastOrNull() as? Bundle ?: return null
            val simples = ultima.getCharSequence("sender")?.toString()
            if (!simples.isNullOrBlank()) return simples
            if (Build.VERSION.SDK_INT >= 28) {
                (ultima.getParcelable<Parcelable>("sender_person") as? Person)?.name?.toString()
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private val APPS = setOf(
            "com.whatsapp",
            "com.whatsapp.w4b",
            "org.telegram.messenger",
            "org.thoughtcrime.securesms",
            "com.google.android.apps.messaging",
            "com.samsung.android.messaging",
            "com.android.mms",
            "com.facebook.orca",
            "com.instagram.android"
        )

        private val recentes = ArrayList<String>()

        private fun registrar(tipo: String, texto: String) {
            val hora = SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date())
            synchronized(recentes) {
                recentes.add("$hora  $tipo: ${texto.take(80)}")
                while (recentes.size > 10) recentes.removeAt(0)
            }
        }

        /** Últimos nomes detectados, do mais novo para o mais antigo. Só em RAM. */
        fun ultimos(): List<String> = synchronized(recentes) { recentes.reversed() }

        /** Aceita nomes separados por vírgula, ponto e vírgula ou um por linha. */
        fun listaVip(texto: String): List<String> =
            texto.split(Regex("[,;\\n]")).map { it.trim() }.filter { it.isNotEmpty() }

        private fun limpar(s: String): String =
            Normalizer.normalize(s, Normalizer.Form.NFD)
                .replace(Regex("\\p{M}+"), "")
                .lowercase()
                .replace(Regex("[^a-z0-9]+"), " ")
                .trim()

        /** Acha o nome VIP que aparece como palavras inteiras dentro do texto. */
        private fun acharVip(texto: String, vips: List<String>): String? {
            val alvo = " " + limpar(texto) + " "
            return vips.firstOrNull { nome ->
                val v = limpar(nome)
                v.isNotEmpty() && alvo.contains(" $v ")
            }
        }
    }
}
