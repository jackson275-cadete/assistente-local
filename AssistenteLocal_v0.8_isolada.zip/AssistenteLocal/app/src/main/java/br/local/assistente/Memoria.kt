package br.local.assistente

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.io.IOException
import java.security.GeneralSecurityException

/**
 * Memória do assistente: fica só no aparelho, criptografada.
 * Só aceita chaves da lista permitida e recusa valores que pareçam
 * números longos (cartão, documentos) ou que passem de [MAX_VALOR] caracteres.
 *
 * As regras ficam em [NucleoMemoria]; esta classe só liga essas regras ao
 * EncryptedSharedPreferences (mesma criptografia da v0.7: chaves AES256_SIV,
 * valores AES256_GCM, arquivo "memoria_assistente").
 *
 * Resultados dos métodos (ver MEMORIA_METODOS.md):
 * - [salvar] e [salvarComResultado]: gravam com commit() e releem o valor. Só dão sucesso
 *   se o valor chegou ao armazenamento. Valor recusado ou falha nunca troca o valor anterior.
 * - [texto], [inteiro], [longo]: devolvem o padrão se a chave não existe ou não pôde ser lida.
 * - [lerTudo] e [tudo]: [lerTudo] informa o motivo quando a leitura falha.
 * - [esquecerTudo]: confere se a memória ficou vazia; se falhar, restaura o conteúdo.
 *
 * Se a criptografia não puder ser aberta, a memória fica indisponível ([disponivel] = false):
 * nada é gravado em texto aberto e nada é apagado automaticamente.
 */
class Memoria(ctx: Context) {

    private val nucleo: NucleoMemoria = criarNucleo(ctx)

    /** false se a memória criptografada não pôde ser aberta. */
    val disponivel: Boolean get() = nucleo.disponivel

    /** Motivo de a memória estar indisponível, ou null se está disponível. */
    val motivoIndisponivel: String? get() = nucleo.motivoIndisponivel

    /** Descrição do erro mais recente, sem conteúdo guardado. */
    val ultimoErro: String? get() = nucleo.ultimoErro

    fun permitido(chave: String): Boolean = NucleoMemoria.permitido(chave)

    /**
     * Retorna true somente se o valor foi gravado e confirmado.
     * Retorna false se a chave ou o valor não forem aceitos, ou se a gravação falhar.
     * Em nenhum caso o valor anterior é trocado ou cortado.
     */
    fun salvar(chave: String, valor: String): Boolean = salvarComResultado(chave, valor).ok

    /** Como [salvar], mas diz o motivo quando não grava. */
    fun salvarComResultado(chave: String, valor: String): ResultadoGravacao =
        nucleo.salvar(chave, valor)

    fun texto(chave: String, padrao: String = ""): String = nucleo.texto(chave, padrao)

    fun inteiro(chave: String, padrao: Int): Int = nucleo.inteiro(chave, padrao)

    fun longo(chave: String, padrao: Long = 0L): Long = nucleo.longo(chave, padrao)

    fun tudo(): Map<String, String> = nucleo.tudo()

    /** Tudo o que está guardado e, se a leitura falhar, o motivo. */
    fun lerTudo(): LeituraMemoria = nucleo.lerTudo()

    /** Apaga tudo e confere. [ResultadoGravacao.GRAVADO] significa que a memória ficou vazia. */
    fun esquecerTudo(): ResultadoGravacao = nucleo.esquecerTudo()

    companion object {
        /** Tamanho máximo de um valor, em caracteres. */
        const val MAX_VALOR = NucleoMemoria.MAX_VALOR

        /** Trava única do processo: Activity, serviço e listener usam a mesma. */
        private val TRAVA = Any()

        private fun criarNucleo(ctx: Context): NucleoMemoria {
            return try {
                val prefs = EncryptedSharedPreferences.create(
                    ctx.applicationContext,
                    "memoria_assistente",
                    MasterKey.Builder(ctx.applicationContext)
                        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                        .build(),
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
                NucleoMemoria(ArmazemPrefs(prefs), null, TRAVA)
            } catch (e: GeneralSecurityException) {
                NucleoMemoria(null, "Falha de criptografia ao abrir a memória (${e.javaClass.simpleName})", TRAVA)
            } catch (e: IOException) {
                NucleoMemoria(null, "Falha ao abrir o arquivo da memória (${e.javaClass.simpleName})", TRAVA)
            }
        }
    }
}

/**
 * Liga o [NucleoMemoria] a um SharedPreferences (o criptografado, em produção).
 * Grava com commit(), que informa se a escrita em disco deu certo (apply() não informa).
 * Falhas de cifrar ou decifrar viram [FalhaArmazem]; nenhum outro erro é escondido.
 */
internal class ArmazemPrefs(private val prefs: SharedPreferences) : ArmazemChaveValor {

    override fun ler(chave: String): String? {
        try {
            return prefs.getString(chave, null)
        } catch (e: SecurityException) {
            throw FalhaArmazem(true, "Falha ao decifrar um valor (${e.javaClass.simpleName})", e)
        } catch (e: ClassCastException) {
            throw FalhaArmazem(false, "Valor guardado com tipo inesperado", e)
        }
    }

    override fun gravar(chave: String, valor: String): Boolean {
        try {
            return prefs.edit().putString(chave, valor).commit()
        } catch (e: SecurityException) {
            throw FalhaArmazem(true, "Falha ao cifrar um valor (${e.javaClass.simpleName})", e)
        }
    }

    override fun remover(chave: String): Boolean {
        try {
            return prefs.edit().remove(chave).commit()
        } catch (e: SecurityException) {
            throw FalhaArmazem(true, "Falha ao cifrar durante a remoção (${e.javaClass.simpleName})", e)
        }
    }

    override fun limpar(): Boolean {
        try {
            return prefs.edit().clear().commit()
        } catch (e: SecurityException) {
            throw FalhaArmazem(true, "Falha de criptografia ao apagar (${e.javaClass.simpleName})", e)
        }
    }

    override fun todos(): Map<String, String> {
        try {
            val mapa = mutableMapOf<String, String>()
            for ((k, v) in prefs.all) {
                if (v is String) mapa[k] = v
            }
            return mapa
        } catch (e: SecurityException) {
            throw FalhaArmazem(true, "Falha ao decifrar a memória (${e.javaClass.simpleName})", e)
        }
    }
}
