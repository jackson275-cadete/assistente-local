# Memória do Assistente — métodos e resultados (v0.8, Etapa 2)

Arquivos: `Memoria.kt` (liga ao Android) e `NucleoMemoria.kt` (regras, sem Android).
Criptografia mantida como na v0.7: EncryptedSharedPreferences, arquivo `memoria_assistente`,
chaves AES256_SIV, valores AES256_GCM, MasterKey AES256_GCM.

## Regras de validação (antes de qualquer gravação)
Ordem: 1) chave permitida; 2) tamanho; 3) número longo.
- Chaves permitidas: nome, silencio_ini, silencio_fim, voz_ativa, voz_vel, voz_tom, voz_nome,
  auto_inicio, ativo, vip_nomes, vip_ativo, vip_fura_silencio, e prefixos `n_` e `ult_`.
- Tamanho máximo: 600 caracteres (`MAX_VALOR`). Acima disso: recusa. Nunca corta.
- Número longo: 8 ou mais dígitos (depois de remover espaços) é recusado.
Valor recusado = nada é gravado e o valor anterior continua igual.

### Exceção para timestamps internos (correção posterior à Etapa 2)
O MonitorService guarda `System.currentTimeMillis()` (12–13 dígitos) em `ult_hist` e `ult_<id da regra>`.
A regra de número longo recusava esses valores e os intervalos de alerta e histórico nunca eram gravados.
Exceção restrita, só para estas chaves exatas:
`ult_hist`, `ult_bat_critica`, `ult_bat_baixa`, `ult_bat_80`, `ult_quente`, `ult_armazenamento`, `ult_ram`, `ult_bat_queda`.
O valor precisa ser só dígitos (`[1-9]` seguido de 11 ou 12 dígitos), sem espaço, sinal ou zero à esquerda,
e entre 01/01/2000 e 01/01/2100. Qualquer outro valor nessas chaves volta à regra geral (8+ dígitos é recusado).
Nenhuma outra chave tem a exceção, inclusive `ult_resumo` (guarda data AAAA-MM-DD) e `n_*`.
Uma nova regra de alerta no MonitorService precisa ter seu `ult_<id>` acrescentado à lista em `NucleoMemoria.kt`.

## Gravação
| Método | Retorno |
|---|---|
| `salvarComResultado(chave, valor)` | `ResultadoGravacao` |
| `salvar(chave, valor)` | `Boolean`: true só se `GRAVADO` |

Passos: valida → lê valor anterior → grava com `commit()` → relê e compara.
Só devolve `GRAVADO` se o valor lido for igual ao enviado.
Se falhar depois de gravar, o valor anterior é restaurado (ou a chave removida, se não existia).
Se o valor anterior não pôde ser lido, nada é restaurado nem apagado.

| Resultado | Significado |
|---|---|
| GRAVADO | Gravado e conferido |
| CHAVE_NAO_PERMITIDA | Chave fora da lista; nada gravado |
| VALOR_MUITO_LONGO | Mais de 600 caracteres; nada gravado, nada cortado |
| VALOR_RECUSADO | Parece número longo; nada gravado |
| FALHA_CRIPTOGRAFIA | Erro ao cifrar/decifrar; anterior mantido |
| FALHA_GRAVACAO | Disco não confirmou; anterior mantido |
| MEMORIA_INDISPONIVEL | Criptografia não abriu; nada gravado (sem cópia em texto aberto) |

## Leitura
- `texto(chave, padrao)`, `inteiro(chave, padrao)`, `longo(chave, padrao)`: devolvem o padrão se a chave
  não existe, não é número, a leitura falha ou a memória está indisponível. O erro fica em `ultimoErro`.
- `lerTudo()`: `LeituraMemoria(dados, erro)`; `erro` é null se leu tudo.
- `tudo()`: só os dados (mapa vazio se falhar). Use `lerTudo()` para saber o motivo.

## Exclusão
- `esquecerTudo(): ResultadoGravacao`: guarda cópia, apaga, confere se ficou vazio.
  Se falhar, restaura a cópia e devolve FALHA_GRAVACAO ou FALHA_CRIPTOGRAFIA.
  `GRAVADO` significa memória vazia confirmada.
- Não há exclusão de uma chave isolada exposta ao app (só uso interno para desfazer).

## Estado indisponível
Se `EncryptedSharedPreferences.create` falhar (GeneralSecurityException ou IOException),
`disponivel = false` e `motivoIndisponivel` explica. Nada é apagado automaticamente
e nenhum dado é gravado sem criptografia.

## Interface (MainActivity)
- "Salvar": confere cada campo; mostra "Salvo" só se todos foram gravados; senão lista as falhas.
- Voz, "Iniciar/Parar assistente": avisam se o estado não foi guardado.
- "Ver memória": mostra o erro de leitura, não "nada guardado".
- "Esquecer tudo": só apaga histórico e recria a tela se a memória foi apagada de fato.
- Aviso ao abrir o app se a memória estiver indisponível.

## Concorrência
Uma trava única por processo protege ler-gravar-conferir (Activity, serviço, listener).

## Limitações conhecidas
- Um número de 13 dígitos entre 2000 e 2100 (por exemplo, certos números de cartão) seria aceito em
  uma das 8 chaves de timestamp. Essas chaves não são editáveis pelo usuário na interface.
- Tamanho conta caracteres UTF-16, não bytes.
- Testes foram feitos fora do Android (simulação); EncryptedSharedPreferences real não foi testado.
