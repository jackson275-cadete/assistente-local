# Assistente Local (versão 0.1)

Assistente para Android que roda 100% no aparelho, sem internet.

## O que esta versão faz

- Lê bateria, temperatura, RAM e armazenamento.
- Fala sozinho (voz sintetizada) quando algo importa: bateria baixa ou crítica, lembrete dos 80% ao carregar, aparelho quente, armazenamento quase cheio, RAM no limite.
- Resumo falado de manhã (entre 8h e 10h, uma vez por dia).
- Horário de silêncio: nele não fala, só mostra a notificação.
- Memória própria criptografada, com lista do que é permitido guardar, tela para ver tudo e botão para esquecer tudo.
- Aprendizado simples: quanto mais vezes um tipo de aviso já foi dado, mais espaçados ficam os próximos.
- Só lê informações. Não apaga nem altera nada no aparelho.

## O que ainda não tem (próximas versões)

Notícias por RSS, mensagens de contatos VIP, edição de foto e vídeo, widget, comandos de voz, gráficos de histórico, auditoria de permissões.

## Como instalar no Samsung A15

Você precisa de um computador com o Android Studio (gratuito, em developer.android.com/studio).

1. Abra o Android Studio e escolha "Open", selecionando a pasta `AssistenteLocal`.
2. Se ele pedir para configurar o Gradle ou atualizar o plugin, aceite. Espere a sincronização terminar (a primeira vez baixa vários arquivos).
3. No celular, ative o modo desenvolvedor: em Configurações > Sobre o telefone > Informações do software, toque 7 vezes em "Número da versão". Depois, em Opções do desenvolvedor, ative "Depuração USB".
4. Conecte o celular ao computador por cabo USB e autorize a depuração quando o celular perguntar.
5. No Android Studio, escolha o seu celular na barra de cima e clique no botão verde de executar.

Alternativa sem cabo: menu Build > Build APK(s), copie o arquivo `.apk` para o celular e instale (será preciso permitir instalação de fontes desconhecidas).

## Depois de instalar

1. Abra o app, escreva como quer ser chamado e toque em "Salvar".
2. Toque em "Iniciar assistente" e permita as notificações.
3. Toque em "Liberar da economia de bateria" e deixe o app sem restrição. Na Samsung, em geral isso fica em Configurações > Bateria > Limites de uso em segundo plano, onde você adiciona o app em "Apps que nunca dormem". Sem isso, o Android pode encerrar o assistente.

## Se der erro ao compilar

Copie a mensagem de erro e me envie. Este código foi escrito sem poder compilar no ambiente em que foi criado, então pequenos ajustes na primeira execução são esperados.
