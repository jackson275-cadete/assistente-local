package br.local.assistente

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.Normalizer

/**
 * Avisa quando um contato VIP manda mensagem.
 * Olha só as notificações dos apps de mensagem da lista abaixo, compara apenas o
 * título (nome de quem mandou) com os nomes VIP e fala só o nome. Não lê, não guarda
 * e não envia o texto das mensagens.
 */
class VipListener : NotificationListenerService() {

    private lateinit var mem: Memoria
    private lateinit var voz: Voz
    private val handler = Handler(Looper.getMainLooper())
    private val ultimoAviso = HashMap<String, Long>()

    private val apps = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "org.telegram.messenger",
        "com.google.android.apps.messaging",
        "com.samsung.android.messaging",
        "com.facebook.orca",
        "com.instagram.android"
    )

    override fun onCreate() {
        super.onCreate()
        mem = Memoria(this)
        voz = Voz(this, mem)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        voz.parar()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            tratar(sbn)
        } catch (_: Exception) {
            // Qualquer falha aqui não pode derrubar o serviço.
        }
    }

    private fun normalizar(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .lowercase()
            .trim()

    private fun tratar(sbn: StatusBarNotification) {
        if (mem.texto("vip_ativo", "1") != "1") return
        if (sbn.packageName !in apps) return
        if (sbn.isOngoing) return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val titulo = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val alvo = normalizar(titulo)
        if (alvo.isEmpty()) return

        val vips = mem.texto("vip_nomes").split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val achado = vips.firstOrNull { nome ->
            val v = normalizar(nome)
            v.isNotEmpty() && (alvo == v || alvo.startsWith("$v ") || alvo.endsWith(" $v") || alvo.contains(" $v "))
        } ?: return

        if (Alerta.emSilencio(mem) && mem.texto("vip_fura_silencio", "0") != "1") return

        val agora = System.currentTimeMillis()
        val anterior = ultimoAviso[achado] ?: 0L
        if (agora - anterior < 15_000L) return
        ultimoAviso[achado] = agora

        Alerta.chamarAtencao(this, handler)
        if (mem.texto("voz_ativa", "1") == "1") {
            handler.postDelayed({ voz.falar("Mensagem de $achado.", true) }, 1500)
        }
    }
}
