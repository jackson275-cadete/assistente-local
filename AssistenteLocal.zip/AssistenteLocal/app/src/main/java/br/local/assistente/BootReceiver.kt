package br.local.assistente

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Religa o assistente depois que o celular reinicia, mas só se
 * ele estava ligado antes e a opção de início automático está ativa.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        try {
            val mem = Memoria(context)
            if (mem.texto("ativo", "0") != "1") return
            if (mem.texto("auto_inicio", "1") != "1") return
            context.startForegroundService(Intent(context, MonitorService::class.java))
        } catch (_: Exception) {
            // Se o sistema não permitir, o assistente fica para ser iniciado pelo app.
        }
    }
}
