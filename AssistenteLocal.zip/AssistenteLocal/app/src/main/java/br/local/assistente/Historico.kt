package br.local.assistente

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Registro simples de bateria e armazenamento, guardado só no aparelho.
 * Uma linha a cada 15 minutos, com limite de tamanho.
 */
object Historico {

    private const val ARQUIVO = "historico.csv"
    private const val MAX_LINHAS = 2000

    private fun arquivo(ctx: Context): File = File(ctx.filesDir, ARQUIVO)

    fun registrar(ctx: Context, e: Estado, agora: Long) {
        try {
            val f = arquivo(ctx)
            f.appendText("$agora,${e.bateria},${e.armLivreGb},${e.ramLivreMb},${e.tempC}\n")
            if (f.length() > 200_000) {
                val linhas = f.readLines().takeLast(MAX_LINHAS)
                f.writeText(linhas.joinToString("\n") + "\n")
            }
        } catch (_: Exception) {
            // Falha ao registrar não deve afetar o assistente.
        }
    }

    /** Últimos registros, do mais novo para o mais antigo, já em texto. */
    fun ultimos(ctx: Context, quantas: Int): List<String> {
        return try {
            val f = arquivo(ctx)
            if (!f.exists()) return emptyList()
            val formato = SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR"))
            val saida = mutableListOf<String>()
            for (linha in f.readLines().takeLast(quantas)) {
                val p = linha.split(",")
                if (p.size < 5) continue
                val hora = formato.format(Date(p[0].toLong()))
                val livre = "%.1f".format(p[2].toFloat())
                val temp = "%.0f".format(p[4].toFloat())
                saida.add("$hora  bateria ${p[1]}%  livre $livre GB  $temp °C")
            }
            saida.reversed()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun apagar(ctx: Context) {
        try {
            arquivo(ctx).delete()
        } catch (_: Exception) {
        }
    }
}
