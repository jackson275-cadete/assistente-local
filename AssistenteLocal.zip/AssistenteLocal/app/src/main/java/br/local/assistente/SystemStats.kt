package br.local.assistente

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs

data class Estado(
    val bateria: Int,
    val carregando: Boolean,
    val tempC: Float,
    val ramLivreMb: Long,
    val ramTotalMb: Long,
    val ramBaixa: Boolean,
    val armLivreGb: Float,
    val armTotalGb: Float
) {
    val ramLivrePct: Float
        get() = if (ramTotalMb > 0) ramLivreMb * 100f / ramTotalMb else 100f

    val armLivrePct: Float
        get() = if (armTotalGb > 0f) armLivreGb * 100f / armTotalGb else 100f
}

/** Só leitura: nada aqui altera o aparelho. */
object SystemStats {

    fun ler(ctx: Context): Estado {
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val nivel = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val escala = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (nivel >= 0 && escala > 0) nivel * 100 / escala else -1
        val status = bat?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val carregando = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f

        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val mb = 1024L * 1024L

        val st = StatFs(Environment.getDataDirectory().path)
        val gb = 1024f * 1024f * 1024f

        return Estado(
            bateria = pct,
            carregando = carregando,
            tempC = temp,
            ramLivreMb = mi.availMem / mb,
            ramTotalMb = mi.totalMem / mb,
            ramBaixa = mi.lowMemory,
            armLivreGb = st.availableBytes / gb,
            armTotalGb = st.totalBytes / gb
        )
    }
}
