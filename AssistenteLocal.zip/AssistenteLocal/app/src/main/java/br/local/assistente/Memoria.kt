package br.local.assistente

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Memória do assistente: fica só no aparelho, criptografada.
 * Só aceita chaves da lista permitida e recusa valores que pareçam
 * números longos (cartão, documentos).
 */
class Memoria(ctx: Context) {

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        ctx.applicationContext,
        "memoria_assistente",
        MasterKey.Builder(ctx.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val chavesFixas = setOf(
        "nome", "silencio_ini", "silencio_fim", "voz_ativa",
        "voz_vel", "voz_tom", "voz_nome", "auto_inicio", "ativo",
        "vip_nomes", "vip_ativo", "vip_fura_silencio"
    )
    private val numeroLongo = Regex("\\d{8,}")

    fun permitido(chave: String): Boolean =
        chave in chavesFixas || chave.startsWith("n_") || chave.startsWith("ult_")

    /** Retorna false se a chave ou o valor não forem aceitos. */
    fun salvar(chave: String, valor: String): Boolean {
        if (!permitido(chave)) return false
        if (numeroLongo.containsMatchIn(valor.replace(" ", ""))) return false
        prefs.edit().putString(chave, valor.take(600)).apply()
        return true
    }

    fun texto(chave: String, padrao: String = ""): String =
        prefs.getString(chave, null) ?: padrao

    fun inteiro(chave: String, padrao: Int): Int =
        texto(chave).toIntOrNull() ?: padrao

    fun longo(chave: String, padrao: Long = 0L): Long =
        texto(chave).toLongOrNull() ?: padrao

    fun tudo(): Map<String, String> {
        val mapa = mutableMapOf<String, String>()
        for ((k, v) in prefs.all) {
            if (v is String) mapa[k] = v
        }
        return mapa
    }

    fun esquecerTudo() {
        prefs.edit().clear().apply()
    }
}
