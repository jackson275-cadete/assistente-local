package br.local.assistente

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.UUID

/** Voz sintetizada do aparelho, em português do Brasil. */
class Voz(ctx: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(ctx.applicationContext, this)
    private var pronto = false
    private val fila = ArrayDeque<String>()

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status == TextToSpeech.SUCCESS) {
            t.language = Locale("pt", "BR")
            t.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            pronto = true
            while (fila.isNotEmpty()) falar(fila.removeFirst())
        }
    }

    fun falar(texto: String) {
        if (!pronto) {
            fila.addLast(texto)
            return
        }
        tts?.speak(texto, TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
    }

    fun parar() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
