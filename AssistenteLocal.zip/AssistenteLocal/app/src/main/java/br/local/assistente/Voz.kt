package br.local.assistente

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.UUID

/**
 * Voz sintetizada do aparelho, em português do Brasil.
 * Usa velocidade, tom e voz salvos na memória (se houver).
 * Fala normal sai no volume de mídia; fala de alerta sai no volume de alarme.
 * Se algo falhar, chama aoFalhar com uma mensagem em português.
 */
class Voz(
    ctx: Context,
    private val mem: Memoria? = null,
    private val aoFalhar: ((String) -> Unit)? = null,
    private val aoPronto: ((Voz) -> Unit)? = null
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(ctx.applicationContext, this)
    private var pronto = false
    private val fila = ArrayDeque<Pair<String, Boolean>>()

    private val atributosMidia: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    private val atributosAlarme: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            aoFalhar?.invoke("O mecanismo de voz do aparelho não iniciou.")
            return
        }

        val r = t.setLanguage(Locale("pt", "BR"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(Locale.getDefault())
            aoFalhar?.invoke("A voz em português não está instalada. Usando o idioma padrão.")
        }

        t.setAudioAttributes(atributosMidia)
        aplicarConfig(t)

        pronto = true
        aoPronto?.invoke(this)
        while (fila.isNotEmpty()) {
            val item = fila.removeFirst()
            falar(item.first, item.second)
        }
    }

    private fun aplicarConfig(t: TextToSpeech) {
        val m = mem ?: return
        val vel = (m.texto("voz_vel").toFloatOrNull() ?: 1f).coerceIn(0.5f, 2f)
        val tom = (m.texto("voz_tom").toFloatOrNull() ?: 1f).coerceIn(0.5f, 2f)
        t.setSpeechRate(vel)
        t.setPitch(tom)
        val nome = m.texto("voz_nome")
        if (nome.isNotBlank()) usarVoz(nome)
    }

    /** Nomes das vozes em português instaladas no aparelho. */
    fun vozesPt(): List<String> {
        return try {
            val todas = tts?.voices ?: return emptyList()
            todas.filter { it.locale.language == "pt" }.map { it.name }.sorted()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun usarVoz(nome: String): Boolean {
        return try {
            val t = tts ?: return false
            val v = t.voices?.firstOrNull { it.name == nome } ?: return false
            t.setVoice(v)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun falar(texto: String, alerta: Boolean = false) {
        val t = tts
        if (!pronto || t == null) {
            fila.addLast(Pair(texto, alerta))
            return
        }
        t.setAudioAttributes(if (alerta) atributosAlarme else atributosMidia)
        val r = t.speak(texto, TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
        if (r == TextToSpeech.ERROR) {
            aoFalhar?.invoke("Não consegui falar agora.")
        }
    }

    fun parar() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
