package br.local.assistente

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import java.time.LocalDate
import java.time.LocalTime

/**
 * Serviço em segundo plano: confere o aparelho a cada 5 minutos e avisa
 * por notificação e por voz. Só observa, nunca altera o sistema.
 */
class MonitorService : Service() {

    private lateinit var mem: Memoria
    private lateinit var voz: Voz
    private val handler = Handler(Looper.getMainLooper())

    private val ciclo = object : Runnable {
        override fun run() {
            try {
                verificar()
            } catch (_: Exception) {
                // Uma falha numa leitura não derruba o assistente.
            }
            handler.postDelayed(this, INTERVALO_MS)
        }
    }

    private class Regra(
        val id: String,
        val ativa: Boolean,
        val fala: String,
        val intervaloMs: Long,
        val importante: Boolean = false
    )

    override fun onCreate() {
        super.onCreate()
        mem = Memoria(this)
        voz = Voz(this, mem)
        criarCanais()

        val notificacao = Notification.Builder(this, CANAL_FIXO)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Assistente ativo")
            .setContentText("Cuidando do seu aparelho")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_FIXO, notificacao, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_FIXO, notificacao)
        }

        handler.post(ciclo)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        voz.parar()
        super.onDestroy()
    }

    private fun verificar() {
        val e = SystemStats.ler(this)
        val agora = System.currentTimeMillis()
        val nome = mem.texto("nome")
        val tratamento = if (nome.isNotBlank()) ", $nome" else ""
        val podeFalar = mem.texto("voz_ativa", "1") == "1" && !emSilencio()

        // Histórico local, uma linha a cada 15 minutos.
        if (agora - mem.longo("ult_hist") >= 15 * MIN) {
            mem.salvar("ult_hist", agora.toString())
            Historico.registrar(this, e, agora)
        }

        resumoDaManha(e, tratamento, podeFalar)

        val regras = listOf(
            Regra(
                "bat_critica",
                !e.carregando && e.bateria in 0..8,
                "Atenção$tratamento, a bateria está em ${e.bateria} por cento. Conecte o carregador agora.",
                30 * MIN,
                true
            ),
            Regra(
                "bat_baixa",
                !e.carregando && e.bateria in 9..20,
                "A bateria está em ${e.bateria} por cento$tratamento. Vale conectar o carregador.",
                60 * MIN
            ),
            Regra(
                "bat_80",
                e.carregando && e.bateria in 80..99,
                "A bateria chegou a ${e.bateria} por cento. Pode desconectar para preservar a vida útil dela.",
                6 * 60 * MIN
            ),
            Regra(
                "quente",
                e.tempC >= 42f,
                "O aparelho está com ${e.tempC.toInt()} graus$tratamento. Evite usar enquanto ele carrega.",
                45 * MIN,
                true
            ),
            Regra(
                "armazenamento",
                e.armLivrePct < 10f,
                "O armazenamento está quase cheio, restam ${"%.1f".format(e.armLivreGb)} gigas livres.",
                24 * 60 * MIN
            ),
            Regra(
                "ram",
                e.ramBaixa || e.ramLivrePct < 8f,
                "A memória RAM está quase toda em uso. Se o aparelho ficar lento, feche alguns apps.",
                6 * 60 * MIN
            )
        )

        for (r in regras) {
            if (!r.ativa) continue
            // Aprendizado simples: quanto mais vezes já avisou, mais espaçado fica (até 3 vezes).
            val vezes = mem.inteiro("n_${r.id}", 0)
            val espera = (r.intervaloMs * (1f + minOf(vezes, 20) / 10f)).toLong()
            val ultimo = mem.longo("ult_${r.id}")
            if (agora - ultimo < espera) continue

            mem.salvar("ult_${r.id}", agora.toString())
            mem.salvar("n_${r.id}", (vezes + 1).toString())
            avisar(r.id, r.fala, podeFalar, r.importante)
        }
    }

    private fun resumoDaManha(e: Estado, tratamento: String, podeFalar: Boolean) {
        if (!podeFalar) return
        val hoje = LocalDate.now().toString()
        val hora = LocalTime.now().hour
        if (hora !in 8..10 || mem.texto("ult_resumo") == hoje) return

        mem.salvar("ult_resumo", hoje)
        val texto = "Bom dia$tratamento. A bateria está em ${e.bateria} por cento e há " +
            "${"%.0f".format(e.armLivreGb)} gigas livres no armazenamento."
        avisar("resumo", texto, true)
    }

    private fun emSilencio(): Boolean {
        val ini = mem.inteiro("silencio_ini", 22)
        val fim = mem.inteiro("silencio_fim", 7)
        val hora = LocalTime.now().hour
        return when {
            ini == fim -> false
            ini < fim -> hora in ini until fim
            else -> hora >= ini || hora < fim
        }
    }

    private fun avisar(id: String, texto: String, falar: Boolean, importante: Boolean = false) {
        val nm = getSystemService(NotificationManager::class.java)
        val n = Notification.Builder(this, CANAL_ALERTA)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Assistente")
            .setContentText(texto)
            .setStyle(Notification.BigTextStyle().bigText(texto))
            .setAutoCancel(true)
            .build()
        nm.notify(id.hashCode(), n)

        if (!falar) return
        if (importante) {
            chamarAtencao()
            handler.postDelayed({ voz.falar(texto, true) }, 1500)
        } else {
            voz.falar(texto)
        }
    }

    /** Som curto de alerta no volume de alarme, mais vibração. */
    private fun chamarAtencao() {
        try {
            val vib = getSystemService(Vibrator::class.java)
            vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1))
        } catch (_: Exception) {
        }
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val toque = RingtoneManager.getRingtone(this, uri)
            toque.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            toque.play()
            handler.postDelayed({
                try {
                    toque.stop()
                } catch (_: Exception) {
                }
            }, 2500)
        } catch (_: Exception) {
        }
    }

    private fun criarCanais() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CANAL_FIXO, "Assistente ativo", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CANAL_ALERTA, "Avisos do assistente", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    companion object {
        const val CANAL_FIXO = "assistente_fixo"
        const val CANAL_ALERTA = "assistente_alertas"
        const val ID_FIXO = 1
        const val MIN = 60_000L
        const val INTERVALO_MS = 5 * MIN
    }
}
