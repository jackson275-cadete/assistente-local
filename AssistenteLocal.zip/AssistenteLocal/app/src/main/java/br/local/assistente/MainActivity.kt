package br.local.assistente

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var mem: Memoria
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())

    private val atualizar = object : Runnable {
        override fun run() {
            status.text = resumo()
            handler.postDelayed(this, 3000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun botao(rotulo: String, acao: () -> Unit): Button {
        val b = Button(this)
        b.text = rotulo
        b.isAllCaps = false
        b.setOnClickListener { acao() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mem = Memoria(this)

        val raiz = LinearLayout(this)
        raiz.orientation = LinearLayout.VERTICAL
        raiz.setPadding(dp(20), dp(28), dp(20), dp(28))

        val titulo = TextView(this)
        titulo.text = "Assistente Local"
        titulo.textSize = 26f
        titulo.setTypeface(titulo.typeface, Typeface.BOLD)
        raiz.addView(titulo)

        status = TextView(this)
        status.textSize = 16f
        status.setPadding(0, dp(12), 0, dp(12))
        raiz.addView(status)

        val campoNome = EditText(this)
        campoNome.hint = "Como devo te chamar?"
        campoNome.setText(mem.texto("nome"))
        campoNome.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        raiz.addView(campoNome)

        val campoIni = EditText(this)
        campoIni.hint = "Silêncio a partir de (hora, 0 a 23)"
        campoIni.setText(mem.inteiro("silencio_ini", 22).toString())
        campoIni.inputType = InputType.TYPE_CLASS_NUMBER
        raiz.addView(campoIni)

        val campoFim = EditText(this)
        campoFim.hint = "Silêncio até (hora, 0 a 23)"
        campoFim.setText(mem.inteiro("silencio_fim", 7).toString())
        campoFim.inputType = InputType.TYPE_CLASS_NUMBER
        raiz.addView(campoFim)

        val chaveVoz = Switch(this)
        chaveVoz.text = "Falar sozinho"
        chaveVoz.isChecked = mem.texto("voz_ativa", "1") == "1"
        chaveVoz.setPadding(0, dp(12), 0, dp(12))
        raiz.addView(chaveVoz)

        raiz.addView(botao("Salvar") {
            val nomeOk = mem.salvar("nome", campoNome.text.toString().trim())
            val ini = (campoIni.text.toString().toIntOrNull() ?: 22).coerceIn(0, 23)
            val fim = (campoFim.text.toString().toIntOrNull() ?: 7).coerceIn(0, 23)
            mem.salvar("silencio_ini", ini.toString())
            mem.salvar("silencio_fim", fim.toString())
            mem.salvar("voz_ativa", if (chaveVoz.isChecked) "1" else "0")
            val msg = if (nomeOk) "Salvo" else "Salvei o resto, mas esse nome não foi aceito"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        })

        raiz.addView(botao("Iniciar assistente") {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            startForegroundService(Intent(this, MonitorService::class.java))
            Toast.makeText(this, "Assistente iniciado", Toast.LENGTH_SHORT).show()
        })

        raiz.addView(botao("Parar assistente") {
            stopService(Intent(this, MonitorService::class.java))
            Toast.makeText(this, "Assistente parado", Toast.LENGTH_SHORT).show()
        })

        raiz.addView(botao("Liberar da economia de bateria") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        raiz.addView(botao("Ver o que ele lembra") { mostrarMemoria() })
        raiz.addView(botao("Esquecer tudo") { confirmarEsquecer() })

        val rolagem = ScrollView(this)
        rolagem.addView(raiz)
        setContentView(rolagem)
    }

    override fun onResume() {
        super.onResume()
        handler.post(atualizar)
    }

    override fun onPause() {
        handler.removeCallbacks(atualizar)
        super.onPause()
    }

    private fun resumo(): String {
        val e = SystemStats.ler(this)
        val estado = if (e.carregando) "carregando" else "descarregando"
        return "Bateria: ${e.bateria}% ($estado), ${"%.1f".format(e.tempC)} °C\n" +
            "RAM livre: ${e.ramLivreMb} MB de ${e.ramTotalMb} MB\n" +
            "Armazenamento livre: ${"%.1f".format(e.armLivreGb)} GB de ${"%.0f".format(e.armTotalGb)} GB"
    }

    private fun mostrarMemoria() {
        val texto = mem.tudo().entries
            .sortedBy { it.key }
            .joinToString("\n") { "${it.key}: ${it.value}" }
        AlertDialog.Builder(this)
            .setTitle("Memória do assistente")
            .setMessage(if (texto.isBlank()) "Ainda não guardei nada." else texto)
            .setPositiveButton("Fechar", null)
            .show()
    }

    private fun confirmarEsquecer() {
        AlertDialog.Builder(this)
            .setTitle("Esquecer tudo?")
            .setMessage("Isso apaga tudo o que o assistente guardou sobre você.")
            .setPositiveButton("Apagar") { _, _ ->
                mem.esquecerTudo()
                recreate()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
