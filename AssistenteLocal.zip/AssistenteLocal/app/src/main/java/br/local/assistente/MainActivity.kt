package br.local.assistente

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var mem: Memoria
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var vozTeste: Voz? = null

    private val atualizar = object : Runnable {
        override fun run() {
            status.text = resumo()
            handler.postDelayed(this, 3000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun legenda(texto: String): TextView {
        val t = TextView(this)
        t.text = texto
        t.textSize = 14f
        t.setPadding(dp(4), dp(12), 0, 0)
        return t
    }

    private fun botao(rotulo: String, acao: () -> Unit): Button {
        val b = Button(this)
        b.text = rotulo
        b.isAllCaps = false
        b.setOnClickListener { acao() }
        return b
    }

    // Barra de 0 a 100 que representa valores de 0,5 a 2,0 (1,0 é o normal).
    private fun paraProgresso(v: Float): Int = ((v - 0.5f) / 1.5f * 100f).toInt().coerceIn(0, 100)

    private fun deProgresso(p: Int): Float = Math.round((0.5f + p * 1.5f / 100f) * 100) / 100f

    private fun barra(valor: Float): SeekBar {
        val s = SeekBar(this)
        s.max = 100
        s.progress = paraProgresso(valor)
        return s
    }

    private fun novaVozDeTeste(): Voz {
        vozTeste?.parar()
        val v = Voz(this, mem, { msg ->
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        })
        vozTeste = v
        return v
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mem = Memoria(this)

        val raiz = LinearLayout(this)
        raiz.orientation = LinearLayout.VERTICAL
        raiz.setPadding(dp(20), dp(28), dp(20), dp(28))

        val titulo = TextView(this)
        titulo.text = "Assistente Local"
        titulo.textSize = 26f
        titulo.setTypeface(titulo.typeface, Typeface.BOLD)
        raiz.addView(titulo)

        val versao = TextView(this)
        versao.text = "Versão " + (try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (_: Exception) {
            "?"
        })
        versao.textSize = 14f
        raiz.addView(versao)

        status = TextView(this)
        status.textSize = 16f
        status.setPadding(0, dp(12), 0, dp(12))
        raiz.addView(status)

        val campoNome = EditText(this)
        campoNome.hint = "Como devo te chamar?"
        campoNome.setText(mem.texto("nome"))
        campoNome.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        raiz.addView(campoNome)

        raiz.addView(legenda("Silêncio a partir de (hora, 0 a 23)"))
        val campoIni = EditText(this)
        campoIni.hint = "Silêncio a partir de (hora, 0 a 23)"
        campoIni.setText(mem.inteiro("silencio_ini", 22).toString())
        campoIni.inputType = InputType.TYPE_CLASS_NUMBER
        raiz.addView(campoIni)

        raiz.addView(legenda("Silêncio até (hora, 0 a 23)"))
        val campoFim = EditText(this)
        campoFim.hint = "Silêncio até (hora, 0 a 23)"
        campoFim.setText(mem.inteiro("silencio_fim", 7).toString())
        campoFim.inputType = InputType.TYPE_CLASS_NUMBER
        raiz.addView(campoFim)

        raiz.addView(legenda("Velocidade da fala"))
        val barraVel = barra(mem.texto("voz_vel").toFloatOrNull() ?: 1f)
        raiz.addView(barraVel)

        raiz.addView(legenda("Tom da voz"))
        val barraTom = barra(mem.texto("voz_tom").toFloatOrNull() ?: 1f)
        raiz.addView(barraTom)

        val chaveVoz = Switch(this)
        chaveVoz.text = "Falar sozinho"
        chaveVoz.isChecked = mem.texto("voz_ativa", "1") == "1"
        chaveVoz.setPadding(0, dp(12), 0, dp(4))
        raiz.addView(chaveVoz)

        val chaveAuto = Switch(this)
        chaveAuto.text = "Iniciar sozinho ao ligar o celular"
        chaveAuto.isChecked = mem.texto("auto_inicio", "1") == "1"
        chaveAuto.setPadding(0, dp(4), 0, dp(4))
        raiz.addView(chaveAuto)

        raiz.addView(legenda("Contatos VIP: nomes como aparecem na notificação, separados por vírgula ou um por linha"))
        val campoVip = EditText(this)
        campoVip.hint = "Ex.: Maria, João Silva"
        campoVip.setText(mem.texto("vip_nomes"))
        campoVip.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        raiz.addView(campoVip)

        val chaveVip = Switch(this)
        chaveVip.text = "Avisar mensagens VIP"
        chaveVip.isChecked = mem.texto("vip_ativo", "1") == "1"
        chaveVip.setPadding(0, dp(12), 0, dp(4))
        raiz.addView(chaveVip)

        val chaveFura = Switch(this)
        chaveFura.text = "VIP também fala no horário de silêncio"
        chaveFura.isChecked = mem.texto("vip_fura_silencio", "0") == "1"
        chaveFura.setPadding(0, dp(4), 0, dp(12))
        raiz.addView(chaveFura)

        fun salvarVoz() {
            mem.salvar("voz_vel", deProgresso(barraVel.progress).toString())
            mem.salvar("voz_tom", deProgresso(barraTom.progress).toString())
        }

        raiz.addView(botao("Salvar") {
            val nomeOk = mem.salvar("nome", campoNome.text.toString().trim())
            val ini = (campoIni.text.toString().toIntOrNull() ?: 22).coerceIn(0, 23)
            val fim = (campoFim.text.toString().toIntOrNull() ?: 7).coerceIn(0, 23)
            mem.salvar("silencio_ini", ini.toString())
            mem.salvar("silencio_fim", fim.toString())
            mem.salvar("voz_ativa", if (chaveVoz.isChecked) "1" else "0")
            mem.salvar("auto_inicio", if (chaveAuto.isChecked) "1" else "0")
            val vipLista = VipListener.listaVip(campoVip.text.toString())
            val vipOk = mem.salvar("vip_nomes", vipLista.joinToString(", "))
            if (vipOk) campoVip.setText(vipLista.joinToString(", "))
            mem.salvar("vip_ativo", if (chaveVip.isChecked) "1" else "0")
            mem.salvar("vip_fura_silencio", if (chaveFura.isChecked) "1" else "0")
            salvarVoz()
            val msg = if (nomeOk && vipOk) "Salvo: ${vipLista.size} contatos VIP" else "Salvei o resto, mas um campo não foi aceito (números longos não são guardados)"
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        })

        raiz.addView(botao("Testar voz") {
            salvarVoz()
            val v = novaVozDeTeste()
            val e = SystemStats.ler(this)
            val nome = campoNome.text.toString().trim()
            val saudacao = if (nome.isNotEmpty()) "Olá, $nome." else "Olá."
            v.falar(
                "$saudacao Estou funcionando. A bateria está em ${e.bateria} por cento " +
                    "e há ${"%.0f".format(e.armLivreGb)} gigas livres no armazenamento."
            )
            Toast.makeText(this, "Falando...", Toast.LENGTH_SHORT).show()
        })

        raiz.addView(botao("Trocar voz") {
            salvarVoz()
            vozTeste?.parar()
            vozTeste = Voz(this, mem, { msg ->
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }) { voz ->
                val lista = voz.vozesPt()
                if (lista.isEmpty()) {
                    Toast.makeText(this, "Não achei outras vozes em português.", Toast.LENGTH_LONG).show()
                } else {
                    val atual = lista.indexOf(mem.texto("voz_nome"))
                    val proxima = (atual + 1) % lista.size
                    mem.salvar("voz_nome", lista[proxima])
                    voz.usarVoz(lista[proxima])
                    voz.falar("Esta é a voz número ${proxima + 1} de ${lista.size}.")
                }
            }
        })

        raiz.addView(botao("Testar alerta forte") {
            salvarVoz()
            val v = novaVozDeTeste()
            Alerta.chamarAtencao(this, handler)
            handler.postDelayed({ v.falar("Alerta forte. Estou chamando a sua atenção.", true) }, 1500)
        })

        raiz.addView(botao("Testar aviso VIP") {
            salvarVoz()
            val primeiro = campoVip.text.toString().split(",")
                .map { it.trim() }
                .firstOrNull { it.isNotEmpty() }
            val v = novaVozDeTeste()
            Alerta.chamarAtencao(this, handler)
            handler.postDelayed({ v.falar("Mensagem de ${primeiro ?: "um contato VIP"}.", true) }, 1500)
        })

        raiz.addView(botao("Iniciar assistente") {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            mem.salvar("ativo", "1")
            startForegroundService(Intent(this, MonitorService::class.java))
            Toast.makeText(this, "Assistente iniciado", Toast.LENGTH_SHORT).show()
        })

        raiz.addView(botao("Parar assistente") {
            mem.salvar("ativo", "0")
            stopService(Intent(this, MonitorService::class.java))
            Toast.makeText(this, "Assistente parado", Toast.LENGTH_SHORT).show()
        })

        raiz.addView(botao("Liberar da economia de bateria") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        raiz.addView(botao("Liberar acesso às notificações (VIP)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        raiz.addView(botao("Liberar acesso ao uso de apps") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })

        raiz.addView(botao("Apps que mais gastam") { mostrarApps() })

        raiz.addView(botao("Ver últimos nomes detectados") { mostrarDetectados() })

        raiz.addView(botao("Informações do app") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })

        raiz.addView(botao("Ver histórico") { mostrarHistorico() })
        raiz.addView(botao("Ver o que ele lembra") { mostrarMemoria() })
        raiz.addView(botao("Esquecer tudo") { confirmarEsquecer() })

        val rolagem = ScrollView(this)
        rolagem.addView(raiz)
        setContentView(rolagem)
    }

    override fun onResume() {
        super.onResume()
        handler.post(atualizar)
    }

    override fun onPause() {
        handler.removeCallbacks(atualizar)
        super.onPause()
    }

    override fun onDestroy() {
        vozTeste?.parar()
        super.onDestroy()
    }

    private fun resumo(): String {
        val e = SystemStats.ler(this)
        val estado = if (e.carregando) "carregando" else "descarregando"
        return "Bateria: ${e.bateria}% ($estado), ${"%.1f".format(e.tempC)} °C\n" +
            "RAM livre: ${e.ramLivreMb} MB de ${e.ramTotalMb} MB\n" +
            "Armazenamento livre: ${"%.1f".format(e.armLivreGb)} GB de ${"%.0f".format(e.armTotalGb)} GB"
    }

    private fun fmtMin(m: Long): String = if (m >= 60) "${m / 60}h ${m % 60}min" else "$m min"

    private fun fmtMb(mb: Long): String =
        if (mb >= 1024) "${"%.1f".format(mb / 1024f)} GB" else "$mb MB"

    private fun mostrarDetectados() {
        val lista = VipListener.ultimos()
        AlertDialog.Builder(this)
            .setTitle("Últimos nomes detectados")
            .setMessage(
                if (lista.isEmpty())
                    "Nada ainda. Confira se o acesso às notificações está liberado e espere chegar uma mensagem ou ligação. " +
                        "Escreva na lista VIP o nome exatamente como aparece aqui."
                else lista.joinToString("\n")
            )
            .setPositiveButton("Fechar", null)
            .show()
    }

    private fun mostrarApps() {
        if (!AppsUso.temPermissao(this)) {
            AlertDialog.Builder(this)
                .setTitle("Falta uma permissão")
                .setMessage(
                    "Para ver quais apps você mais usa e quais ocupam mais espaço, " +
                        "ative o Assistente Local na lista de acesso ao uso de apps."
                )
                .setPositiveButton("Abrir configuração") { _, _ ->
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
                .setNegativeButton("Cancelar", null)
                .show()
            return
        }
        Toast.makeText(this, "Calculando...", Toast.LENGTH_SHORT).show()
        Thread {
            val usados = AppsUso.maisUsados(this, AppsUso.inicioDoDia(), 8)
            val grandes = AppsUso.maiores(this, 8)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                val t1 = if (usados.isEmpty()) "Sem dados ainda hoje."
                else usados.mapIndexed { i, a -> "${i + 1}. ${a.nome}: ${fmtMin(a.valor)}" }.joinToString("\n")
                val t2 = if (grandes.isEmpty()) "Sem dados."
                else grandes.mapIndexed { i, a -> "${i + 1}. ${a.nome}: ${fmtMb(a.valor)} (${a.extra})" }.joinToString("\n")
                AlertDialog.Builder(this)
                    .setTitle("Apps que mais gastam")
                    .setMessage(
                        "Mais usados hoje (tempo na tela):\n$t1\n\n" +
                            "Mais espaço ocupado:\n$t2\n\n" +
                            "O Android não mostra o gasto de bateria de cada app para outros apps. " +
                                "O tempo de uso é o melhor indicador, e o gasto real fica em Configurações > Bateria."
                    )
                    .setPositiveButton("Fechar", null)
                    .show()
            }
        }.start()
    }

    private fun mostrarHistorico() {
        val linhas = Historico.ultimos(this, 12)
        AlertDialog.Builder(this)
            .setTitle("Histórico recente")
            .setMessage(
                if (linhas.isEmpty()) "Ainda sem registros. Com o assistente ligado, ele anota a cada 15 minutos."
                else linhas.joinToString("\n")
            )
            .setPositiveButton("Fechar", null)
            .show()
    }

    private fun mostrarMemoria() {
        val texto = mem.tudo().entries
            .sortedBy { it.key }
            .joinToString("\n") { "${it.key}: ${it.value}" }
        AlertDialog.Builder(this)
            .setTitle("Memória do assistente")
            .setMessage(if (texto.isBlank()) "Ainda não guardei nada." else texto)
            .setPositiveButton("Fechar", null)
            .show()
    }

    private fun confirmarEsquecer() {
        AlertDialog.Builder(this)
            .setTitle("Esquecer tudo?")
            .setMessage("Isso apaga tudo o que o assistente guardou sobre você, inclusive o histórico e a lista VIP.")
            .setPositiveButton("Apagar") { _, _ ->
                mem.esquecerTudo()
                Historico.apagar(this)
                recreate()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
