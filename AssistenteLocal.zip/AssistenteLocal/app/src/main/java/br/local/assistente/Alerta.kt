package br.local.assistente

import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Handler
import android.os.VibrationEffect
import android.os.Vibrator
import java.time.LocalTime

/** Funções de alerta usadas pelo monitor, pelo aviso VIP e pelos botões de teste. */
object Alerta {

    /** Som curto no volume de alarme (toca mesmo com o celular no silencioso) mais vibração. */
    fun chamarAtencao(ctx: Context, handler: Handler) {
        try {
            val vib = ctx.getSystemService(Vibrator::class.java)
            vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1))
        } catch (_: Exception) {
        }
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val toque = RingtoneManager.getRingtone(ctx, uri)
            toque.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            toque.play()
            handler.postDelayed({
                try {
                    toque.stop()
                } catch (_: Exception) {
                }
            }, 2500)
        } catch (_: Exception) {
        }
    }

    /** Verdadeiro se agora está dentro do horário de silêncio escolhido. */
    fun emSilencio(mem: Memoria): Boolean {
        val ini = mem.inteiro("silencio_ini", 22)
        val fim = mem.inteiro("silencio_fim", 7)
        val hora = LocalTime.now().hour
        return when {
            ini == fim -> false
            ini < fim -> hora in ini until fim
            else -> hora >= ini || hora < fim
        }
    }
}
